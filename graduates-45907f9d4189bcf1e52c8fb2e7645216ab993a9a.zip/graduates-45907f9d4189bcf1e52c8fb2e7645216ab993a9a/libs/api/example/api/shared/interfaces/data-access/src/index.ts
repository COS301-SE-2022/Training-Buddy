export * from './lib/api-example-api-shared-interfaces-data-access.module';
