export function apiExampleServiceFeature(): string {
  return 'api-example-service-feature';
}
