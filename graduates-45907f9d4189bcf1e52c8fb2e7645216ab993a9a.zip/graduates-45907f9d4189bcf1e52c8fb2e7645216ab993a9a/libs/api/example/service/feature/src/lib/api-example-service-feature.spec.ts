import { apiExampleServiceFeature } from './api-example-service-feature';

describe('apiExampleServiceFeature', () => {
  it('should work', () => {
    expect(apiExampleServiceFeature()).toEqual('api-example-service-feature');
  });
});
