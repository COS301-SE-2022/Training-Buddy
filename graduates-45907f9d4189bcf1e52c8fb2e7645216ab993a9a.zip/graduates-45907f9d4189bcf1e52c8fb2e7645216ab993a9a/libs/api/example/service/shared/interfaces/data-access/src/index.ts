export * from './lib/api-example-service-shared-interfaces-data-access.module';
