export * from './lib/api-example-repository-shared-interfaces-data-access.module';
