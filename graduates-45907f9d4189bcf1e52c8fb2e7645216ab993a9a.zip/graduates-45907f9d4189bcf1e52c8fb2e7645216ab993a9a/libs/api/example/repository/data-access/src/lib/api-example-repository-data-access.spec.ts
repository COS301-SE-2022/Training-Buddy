import { apiExampleRepositoryDataAccess } from './api-example-repository-data-access';

describe('apiExampleRepositoryDataAccess', () => {
  it('should work', () => {
    expect(apiExampleRepositoryDataAccess()).toEqual(
      'api-example-repository-data-access'
    );
  });
});
