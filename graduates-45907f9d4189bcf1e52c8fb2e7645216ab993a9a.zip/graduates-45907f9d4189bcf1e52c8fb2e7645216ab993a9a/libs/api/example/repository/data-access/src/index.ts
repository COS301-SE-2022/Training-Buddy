export * from './lib/api-example-repository-data-access';
