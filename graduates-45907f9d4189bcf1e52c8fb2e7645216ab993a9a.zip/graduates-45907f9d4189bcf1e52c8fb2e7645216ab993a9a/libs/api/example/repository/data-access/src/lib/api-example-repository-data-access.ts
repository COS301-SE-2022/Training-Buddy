export function apiExampleRepositoryDataAccess(): string {
  return 'api-example-repository-data-access';
}
