import { Component } from '@angular/core';

@Component({
  selector: 'graduates-shell-feature',
  templateUrl: './feature.component.html',
  styleUrls: ['./feature.component.scss'],
})
export class FeatureComponent {}
