export * from './lib/data-access.module';
