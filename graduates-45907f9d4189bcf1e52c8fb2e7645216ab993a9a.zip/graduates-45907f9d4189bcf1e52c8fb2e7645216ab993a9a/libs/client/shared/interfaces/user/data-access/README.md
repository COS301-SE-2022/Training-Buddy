# client-shared-interfaces-user-data-access

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test client-shared-interfaces-user-data-access` to execute the unit tests.
