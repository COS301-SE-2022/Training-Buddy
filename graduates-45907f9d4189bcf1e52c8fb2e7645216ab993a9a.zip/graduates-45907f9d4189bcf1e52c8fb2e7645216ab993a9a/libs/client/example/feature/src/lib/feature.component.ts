import { Component } from '@angular/core';

@Component({
  selector: 'graduates-example-feature',
  templateUrl: './feature.component.html',
  styleUrls: ['./feature.component.scss'],
})
export class FeatureComponent {}
